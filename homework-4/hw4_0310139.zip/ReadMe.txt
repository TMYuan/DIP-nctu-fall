1. In this homework, I use jupyter notebook. You can open them by
   % jupyter notebook
2. Language: Python 3.6
   Module Dependency:
     numpy,
     scikit-image,
     matplotlib,
     scipy
3. There are 3 file. Each of them stands for one input. Open with jupyter to view the code.
4. The input and output images are all placed in ./data

